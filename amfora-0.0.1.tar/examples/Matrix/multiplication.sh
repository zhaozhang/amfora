#!/bin/bash

cp examples/Matrix/data/matrix.txt /tmp/amfora/
amc.py type row_matrix /tmp/amfora/matrix.txt
amc.py type column_matrix /tmp/amfora/matrix.txt

amc.py allgather /tmp/amfora/.matrix.txt_row_matrix
amc.py scatter /tmp/amfora/.matrix.txt_column_matrix

mkdir /tmp/amfora/temp
for rfile in `ls /tmp/amfora/.matrix.txt_row_matrix`
do
   for cfile in `ls /tmp/amfora/.matrix.txt_column_matrix`
   do
         src/amc.py queue multi /tmp/amfora/.matrix.txt_row_matrix/${rfile} /tmp/amfora/.matrix.txt_column_matrix/${cfile} > /tmp/amfora/temp/${cfile}
   done
   src/amc.py execute
   cat /tmp/amfora/temp/* >> /tmp/amfora/result.matrix
done


#awk 'NR==FNR {
#        for(i=1;i<=NF;i++)A[NR,i]=$i
#        next
#      }
#      {
#        for(i=1;i<NR;i++){
#          t=0
#          for(j=1;j<=NF;j++)
#            t+=A[i,j]*$j
#          printf t FS
#        }
#        print ""
#      }' 2.txt 1.txt	 
