#!/bin/bash

mkdir /tmp/amfora/projdir /tmp/amfora/diffdir /tmp/amfora/statdir /tmp/amfora/corrdir /tmp/amfora/final
sleep 1

cp /var/tmp/Montage/template.hdr /tmp/amfora/
src/amc.py multicast /tmp/amfora/template.hdr
sleep 1

echo "mProjectPP"
cp scratch/mProjectPP-task.txt /tmp/amfora-task.txt
time src/amc.py execute
sleep 1

echo "------------------------------------"
echo "mImgtbl"
src/amc.py queue "mImgtbl /tmp/amfora/projdir /tmp/amfora/images.tbl"
time src/amc.py execute
sleep 1

echo "------------------------------------"
echo "mOverlaps"
src/amc.py queue "mOverlaps /tmp/amfora/images.tbl /tmp/amfora/diffs.tbl"
time src/amc.py execute
sleep 1

echo "------------------------------------"
echo "mDiffFit"
cp scratch/mDiff-task.txt /tmp/amfora-task.txt
time src/amc.py execute
sleep 1

echo "------------------------------------"
echo "mConcatFit"
src/amc.py queue 'for file in `ls /tmp/amfora/statdir/`; do   echo /tmp/amfora/statdir/${file} ;   cat /tmp/amfora/statdir/${file} ;done > /tmp/amfora/stats.tmp; examples/Montage/bin/format-fits.py /tmp/amfora/stats.tmp /tmp/amfora/fits.tbl'
time src/amc.py execute
sleep 1


echo "------------------------------------"
echo "mBgModel"
src/amc.py queue "mBgModel /tmp/amfora/images.tbl /tmp/amfora/fits.tbl /tmp/amfora/corrections.tbl"
time src/amc.py execute
sleep 1


echo "------------------------------------"
echo "mBackground"
cp scratch/mBackground-task.txt /tmp/amfora-task.txt
time src/amc.py execute
sleep 1

echo "------------------------------------"
echo "mImgtbl"
src/amc.py queue "mImgtbl /tmp/amfora/corrdir /tmp/amfora/corr-images.tbl"
time src/amc.py execute
sleep 1

echo "------------------------------------"
echo "mAdd"
src/amc.py queue "mAdd -n -p /tmp/amfora/corrdir /tmp/amfora/corr-images.tbl /tmp/amfora/template.hdr /tmp/amfora/final/m101_corrected.fits"
time src/amc.py execute
sleep 1

