#!/bin/bash
option=${1}

mkdir /tmp/amfora/projdir /tmp/amfora/diffdir /tmp/amfora/statdir /tmp/amfora/corrdir /tmp/amfora/final
sleep 1

cp /var/tmp/Montage/template.hdr /tmp/amfora/
src/amc.py multicast /tmp/amfora/template.hdr
sleep 1


echo "------------------------------------"
echo "mBackground"
cp scratch/mBackground-task-369-pure.txt /tmp/amfora-task.txt
time src/amc.py execute
sleep 1

for i in `seq 1 16`
do
  ssh amfora${i} "rm -rf /dev/shm/scratch/*"
done

host=`head -n 2 etc/gce.conf | tail -n 1`
echo "bin/kill-amfora-one-node.sh ${host} /tmp/amfora"
bin/kill-amfora-one-node.sh ${host} /tmp/amfora
sleep 5
ssh ${host} "cd /var/tmp/AMFORA; bin/launch-amfora-resilient-client.sh /tmp/amfora etc/gce.conf ${host} /var/tmp/AMFORA 3 3600 ${option} 10000000"


echo "------------------------------------"
echo "mImgtbl"
time ssh ${host} "/var/tmp/Montage/Montage_v3.3/bin/mImgtbl /tmp/amfora/corrdir /tmp/amfora/corr-images.tbl"

ssh ${host} "cp /tmp/amfora/corr-images.tbl /var/tmp/Montage/"

for i in `seq 1 16`
do
  ssh amfora${i} "rm -rf /dev/shm/scratch/*"
done


echo "bin/kill-amfora-one-node.sh ${host} /tmp/amfora"
bin/kill-amfora-one-node.sh ${host} /tmp/amfora
sleep 5
ssh ${host} "cd /var/tmp/AMFORA; bin/launch-amfora-resilient-client.sh /tmp/amfora etc/gce.conf ${host} /var/tmp/AMFORA 3 3600 ${option} 10000000"
sleep 5

echo "------------------------------------"
echo "mAdd"
time ssh ${host} "/var/tmp/Montage/Montage_v3.3/bin/mAdd -n -p /tmp/amfora/corrdir /var/tmp/Montage/corr-images.tbl /tmp/amfora/template.hdr /tmp/amfora/final/m101_corrected.fits"
sleep 5

for i in `seq 1 16`
do
  ssh amfora${i} "rm -rf /dev/shm/scratch/*"
done
