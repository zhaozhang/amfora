#!/bin/bash
gcutil listinstances | grep "10." | cut -d '|' -f 5 | cut -d ' ' -f 2
